#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

int main ()

{

char tabAdresse[30];
int pos[3],i,j;

cout<<"Tapez une adresse IP sous la forme xxx.xxx.xxx.xxx"<<endl;
cin.getline(tabAdresse,30);
for(i=0;i<30;i++)
{
if (tabAdresse[i]=='.')
  pos[j]=i;
  j++;
}
cout<<"Le premiere seperateur est "<<pos[0]<<endl;

 return 0;
}